export default {
    en: {
        name: "English (en.db)",
        dev: "http://localhost:8080/en.db",
        production: "http://example.com/en.db"
    }
};