<script>
    export let text
</script>

{@html text}
